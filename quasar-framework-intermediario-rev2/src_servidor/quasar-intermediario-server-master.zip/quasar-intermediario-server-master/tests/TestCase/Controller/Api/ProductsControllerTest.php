<?php
namespace App\Test\TestCase\Controller;

use App\Controller\Api/ProductsController;
use Cake\TestSuite\IntegrationTestCase;

/**
 * App\Controller\Api/ProductsController Test Case
 */
class Api/ProductsControllerTest extends IntegrationTestCase
{

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
